System.register(['angular2/core'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, core_2;
    var TaskServices, ArticleComponent, RedditApp, BookArticle;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            }],
        execute: function() {
            TaskServices = (function () {
                function TaskServices() {
                }
                TaskServices = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], TaskServices);
                return TaskServices;
            })();
            exports_1("TaskServices", TaskServices);
            ArticleComponent = (function () {
                function ArticleComponent() {
                    //this. article = new Article( 'Angular 2' , 'http://angular.io' , 10);
                }
                ArticleComponent.prototype.voteUp = function () {
                    this.bkarticle.voteUp();
                };
                ArticleComponent.prototype.voteDown = function () {
                    this.bkarticle.voteDown();
                };
                ArticleComponent = __decorate([
                    core_2.Component({
                        selector: 'bookArticle',
                        template: "<div class=\"ui items\">\n        <div class=\"item\" *ngFor=\"#contact of bkarticle\">\n            <div class=\"image\">\n              <img src=\"../resources/assets/images/angular.jpg\">\n            </div>\n            <div class=\"content\">\n                <a class=\"header\">{{contact.bookname}}</a>\n                <div class=\"meta\">\n                  <span>{{contact.title}}</span>\n                </div>\n                 <div class=\"description\">\n                     <p></p>\n                 </div>\n                <div class=\"extra\">\n                    {{contact.link}}\n                </div>\n                 <a href=\"javascript:void(0)\" (click)=\"voteBook(contact.bookname)\" class=\"ui button delete-button floating right\">Vote</a>\n             </div>\n         </div>\n    </div>"
                    }), 
                    __metadata('design:paramtypes', [])
                ], ArticleComponent);
                return ArticleComponent;
            })();
            RedditApp = (function () {
                function RedditApp() {
                    this.bkarticle = [
                        new BookArticle('Angular Book 1', 'Angular Book Description 1', 'http://www.google.com', 3),
                        new BookArticle('Angular Book 2', 'Angular Book Description 2', 'http://www.google.com', 2),
                        new BookArticle('Angular Book 3', 'Angular Book Description 3', 'http://www.google.com', 5),
                    ];
                }
                /*   public contactList : ContactlistInterface [] =[
                       {
                       bookname: 'Angular Book 1',
                       title: 'Angular Book Description 1',
                       link: 'http://www.google.com'
                        },
                       {
                           bookname: 'Angular Book 2',
                           title: 'Angular Book Description 2',
                           link: 'http://www.google.com'
                       },
                       {
                           bookname: 'Angular Book 3',
                           title: 'Angular Book Description 3',
                           link: 'http://www.google.com'
                       }
               
                   ];*/
                RedditApp.prototype.addlink = function (bookname, title, link) {
                    //  console.log(`Adding article Book Name : ${bookname.value} and Title: ${title.value} and Link : ${link.value} `);
                    this.bkarticle.push();
                    /*  console.log(this.contactList.push({
                          bookname: bookname.value,
                          title: title.value,
                          link: link.value
                      }));*/
                    bookname.value = "";
                    title.value = "";
                    link.value = "";
                };
                RedditApp = __decorate([
                    core_2.Component({
                        selector: 'reddit',
                        directives: [ArticleComponent],
                        template: "<form class=\"ui large form segment clearing\" >\n        <h3 class=\"ui header\" > Add a Link</h3>\n\n        <div class=\"field\" >\n            <label for=\"title\" > Book Name: </label >\n            <input name=\"title\" type=\"text\" #newbookname>\n        </div>\n        <div class=\" field\" >\n            <label for=\" link\" > Title: </label >\n            <input name=\"link\" #newtitle>\n        </div>\n        <div class=\" field\" >\n            <label for=\" link\" > Link: </label >\n            <input name=\"link\" #newlink>\n        </div>\n\n        <button  class=\" ui positive right floated button\" (click)=\"addlink(newbookname, newtitle, newlink)\" >\n            Submit link\n        </button>\n\n    </form>\n    <div class=\"spaced\"></div>\n    \n        "
                    }), 
                    __metadata('design:paramtypes', [])
                ], RedditApp);
                return RedditApp;
            })();
            exports_1("RedditApp", RedditApp);
            BookArticle = (function () {
                function BookArticle(bookname, title, link, votes) {
                    this.bookname = bookname;
                    this.title = title;
                    this.link = link;
                    this.votes = votes || 0;
                }
                BookArticle.prototype.voteUp = function () {
                    this.votes += 1;
                };
                BookArticle.prototype.voteDown = function () {
                    this.votes -= 1;
                };
                return BookArticle;
            })();
        }
    }
});
//# sourceMappingURL=contactList.service.js.map