System.register(['angular2/core'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var BookArticleComponent, RedditApp, BookArticle;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            BookArticleComponent = (function () {
                function BookArticleComponent() {
                    this.showbook = new BookArticle("Angular Book 1", "Angular Development Course", "http://www.google.com", 1);
                    /*  this.bookname = "Angular Book 1";
                      this.title = "Angular Development Course",
                      this.link = "http://www.google.com",
                      this.votes = 1;*/
                }
                BookArticleComponent.prototype.voteUp = function () {
                    this.showbook.votes += 1;
                    if (this.showbook.votes > 0) {
                        this.addclass = "green";
                    }
                    else {
                        this.addclass = "red";
                    }
                };
                BookArticleComponent.prototype.voteDown = function () {
                    this.showbook.votes -= 1;
                    if (this.showbook.votes > 0) {
                        this.addclass = "green";
                    }
                    else {
                        this.addclass = "red";
                    }
                };
                BookArticleComponent = __decorate([
                    core_1.Component({
                        selector: 'book-article',
                        template: "<div class=\"four wide column center aligned votes\">\n            <h4 class=\"ui large header\">{{showbook.bookname}}</h4>\n            <a class=\"ui header\" href=\"{{showbook.link}}\">\n             {{showbook.title}}\n            </a>\n                <div class=\"ui compact menu\">\n                    <a class=\"item\">\n                        <i class=\"file pdf outline icon\"></i> Points\n                        <div class=\"floating ui {{addclass}} label\"> {{showbook.votes}}</div>\n                    </a>\n  \n                    </div>\n                </div>\n             \n            <div class=\"twelve wide column\">\n            \n             <ul class=\"ui big horizontal list voters\">\n                 <li class=\"item\" style=\"list-style:none;\">\n                     <a href=\"javascript:void(0) \"(click)=\"voteUp()\">\n                         <i class=\"arrow up icon\"></i>\n                          upvote\n                     </a>\n                 </li>\n                 <li class=\"item\">\n                     <a href=\"javascript:void(0)\" (click)=\"voteDown()\">\n                         <i class=\"arrow down icon\"></i>\n                             downvote\n                     </a>\n                 </li>\n               </ul>\n             </div>"
                    }), 
                    __metadata('design:paramtypes', [])
                ], BookArticleComponent);
                return BookArticleComponent;
            })();
            RedditApp = (function () {
                function RedditApp() {
                }
                /* public contactList : ContactlistInterface [] =[
                     {
                     bookname: 'Angular Book 1',
                     title: 'Angular Book Description 1',
                     link: 'http://www.google.com'
                      },
                     {
                         bookname: 'Angular Book 2',
                         title: 'Angular Book Description 2',
                         link: 'http://www.google.com'
                     },
                     {
                         bookname: 'Angular Book 3',
                         title: 'Angular Book Description 3',
                         link: 'http://www.google.com'
                     }
             
                 ];
             */
                RedditApp.prototype.addlink = function (bookname, title, link) {
                    console.log("Adding article Book Name : " + bookname.value + " and Title: " + title.value + " and Link : " + link.value + " ");
                    /*   console.log(this.contactList.push({
                           bookname: bookname.value,
                           title: title.value,
                           link: link.value
                       }));*/
                    bookname.value = "";
                    title.value = "";
                    link.value = "";
                };
                RedditApp = __decorate([
                    core_1.Component({
                        selector: 'reddit',
                        directives: [BookArticleComponent],
                        template: "<form class=\"ui large form segment clearing\" >\n        <h3 class=\"ui header\" > Add a Link</h3>\n\n        <div class=\"field\" >\n            <label for=\"title\" > Book Name: </label >\n            <input name=\"title\" type=\"text\" #newbookname>\n        </div>\n        <div class=\" field\" >\n            <label for=\" link\" > Title: </label >\n            <input name=\"link\" #newtitle>\n        </div>\n        <div class=\" field\" >\n            <label for=\" link\" > Link: </label >\n            <input name=\"link\" #newlink>\n        </div>\n\n        <button  class=\" ui positive right floated button\" (click)=\"addlink(newbookname, newtitle, newlink)\" >\n            Submit link\n        </button>\n\n    </form>\n    <div class=\"spaced\"></div> \n            <book-article></book-article>\n            "
                    }), 
                    __metadata('design:paramtypes', [])
                ], RedditApp);
                return RedditApp;
            })();
            exports_1("RedditApp", RedditApp);
            BookArticle = (function () {
                function BookArticle(bookname, title, link, votes) {
                    this.bookname = bookname;
                    this.title = title;
                    this.link = link;
                    this.votes = votes || 0;
                }
                BookArticle.prototype.voteUp = function () {
                    this.votes += 1;
                    if (this.votes > 0) {
                        this.addclass = "green";
                    }
                    else {
                        this.addclass = "red";
                    }
                };
                BookArticle.prototype.voteDown = function () {
                    this.votes -= 1;
                    if (this.votes > 0) {
                        this.addclass = "green";
                    }
                    else {
                        this.addclass = "red";
                    }
                };
                return BookArticle;
            })();
        }
    }
});
//# sourceMappingURL=app.component.js.map