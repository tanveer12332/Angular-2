/**
 * Created by tanveer.yousuf on 1/15/2016.
 */
import {Injectable} from 'angular2/core';

@Injectable()

export class TaskServices{

}
import {Component} from 'angular2/core';

interface ContactlistInterface{
    bookname:string;
    title:string;
    link:string;
    votes:number;
}

@Component ({
    selector : 'bookArticle',
    template : `<div class="ui items">
        <div class="item" *ngFor="#contact of bkarticle">
            <div class="image">
              <img src="../resources/assets/images/angular.jpg">
            </div>
            <div class="content">
                <a class="header">{{contact.bookname}}</a>
                <div class="meta">
                  <span>{{contact.title}}</span>
                </div>
                 <div class="description">
                     <p></p>
                 </div>
                <div class="extra">
                    {{contact.link}}
                </div>
                 <a href="javascript:void(0)" (click)="voteBook(contact.bookname)" class="ui button delete-button floating right">Vote</a>
             </div>
         </div>
    </div>`
})
class ArticleComponent{
    bkarticle: BookArticle
    
    constructor() {
        
        //this. article = new Article( 'Angular 2' , 'http://angular.io' , 10);
    }
    
    voteUp() {
        this.bkarticle.voteUp();
        
    }

    voteDown() {
        this.bkarticle.voteDown();
        
    }
}
@Component({
    selector: 'reddit',
    directives : [ArticleComponent],
    template: `<form class="ui large form segment clearing" >
        <h3 class="ui header" > Add a Link</h3>

        <div class="field" >
            <label for="title" > Book Name: </label >
            <input name="title" type="text" #newbookname>
        </div>
        <div class=" field" >
            <label for=" link" > Title: </label >
            <input name="link" #newtitle>
        </div>
        <div class=" field" >
            <label for=" link" > Link: </label >
            <input name="link" #newlink>
        </div>

        <button  class=" ui positive right floated button" (click)="addlink(newbookname, newtitle, newlink)" >
            Submit link
        </button>

    </form>
    <div class="spaced"></div>
    
        `
})
export class RedditApp {
    bkarticle: BookArticle[];
    constructor(){
        this.bkarticle =[
           new BookArticle('Angular Book 1','Angular Book Description 1','http://www.google.com',3),
           new BookArticle('Angular Book 2','Angular Book Description 2','http://www.google.com',2),
           new BookArticle('Angular Book 3','Angular Book Description 3','http://www.google.com',5),
        ];
    }
 /*   public contactList : ContactlistInterface [] =[
        {
        bookname: 'Angular Book 1',
        title: 'Angular Book Description 1',
        link: 'http://www.google.com'
         },
        {
            bookname: 'Angular Book 2',
            title: 'Angular Book Description 2',
            link: 'http://www.google.com'
        },
        {
            bookname: 'Angular Book 3',
            title: 'Angular Book Description 3',
            link: 'http://www.google.com'
        }

    ];*/


    addlink(bookname:HTMLInputElement,title:HTMLInputElement,link:HTMLInputElement) : void{
      //  console.log(`Adding article Book Name : ${bookname.value} and Title: ${title.value} and Link : ${link.value} `);

        this.bkarticle.push()
      /*  console.log(this.contactList.push({
            bookname: bookname.value,
            title: title.value,
            link: link.value
        }));*/
        bookname.value="";
        title.value="";
        link.value="";
           }

  
}

class BookArticle {
    bookname: string;
    title: string;
    link: string;
    votes : number;

    constructor(bookname: string, title: string, link:string, votes?: number) {
        this.bookname = bookname;
        this.title = title;
        this.link=link;
        this.votes = votes || 0;
    }
    
    voteUp() : void {
        this.votes += 1 ;
    }

    voteDown() : void {
        this.votes -= 1 ;
    }
    
}