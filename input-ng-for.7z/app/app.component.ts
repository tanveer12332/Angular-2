import {Component} from 'angular2/core';

interface ContactlistInterface{
    bookname:string;
    title:string;
    link:string;
    
}
@Component({
 selector: 'book-article',
 template: `<div class="four wide column center aligned votes">
            <h4 class="ui large header">{{showbook.bookname}}</h4>
            <a class="ui header" href="{{showbook.link}}">
             {{showbook.title}}
            </a>
                <div class="ui compact menu">
                    <a class="item">
                        <i class="file pdf outline icon"></i> Points
                        <div class="floating ui {{addclass}} label"> {{showbook.votes}}</div>
                    </a>
  
                    </div>
                </div>
             
            <div class="twelve wide column">
            
             <ul class="ui big horizontal list voters">
                 <li class="item" style="list-style:none;">
                     <a href="javascript:void(0) "(click)="voteUp()">
                         <i class="arrow up icon"></i>
                          upvote
                     </a>
                 </li>
                 <li class="item">
                     <a href="javascript:void(0)" (click)="voteDown()">
                         <i class="arrow down icon"></i>
                             downvote
                     </a>
                 </li>
               </ul>
             </div>`
})
 class BookArticleComponent{
   /* votes : number;
    bookname: string;
    title : string;
    link: string;*/
   showbook : BookArticle;
    addclass;
    
    constructor(){
        this.showbook = new BookArticle("Angular Book 1","Angular Development Course","http://www.google.com",1);
      /*  this.bookname = "Angular Book 1";
        this.title = "Angular Development Course",
        this.link = "http://www.google.com",
        this.votes = 1;*/
    }
    voteUp(){
        this.showbook.votes +=1;
        if(this.showbook.votes > 0){
            this.addclass ="green";
        }else{
            this.addclass ="red";
        }
    }
    voteDown(){
         this.showbook.votes -=1;
         if(this.showbook.votes > 0){
            this.addclass ="green";
        }else{
            this.addclass ="red";
        }
    }
}

@Component({
    selector: 'reddit',
    directives:[BookArticleComponent],
    template: `<form class="ui large form segment clearing" >
        <h3 class="ui header" > Add a Link</h3>

        <div class="field" >
            <label for="title" > Book Name: </label >
            <input name="title" type="text" #newbookname>
        </div>
        <div class=" field" >
            <label for=" link" > Title: </label >
            <input name="link" #newtitle>
        </div>
        <div class=" field" >
            <label for=" link" > Link: </label >
            <input name="link" #newlink>
        </div>

        <button  class=" ui positive right floated button" (click)="addlink(newbookname, newtitle, newlink)" >
            Submit link
        </button>

    </form>
    <div class="spaced"></div> 
            <book-article></book-article>
            `
})
export class RedditApp {
   /* public contactList : ContactlistInterface [] =[
        {
        bookname: 'Angular Book 1',
        title: 'Angular Book Description 1',
        link: 'http://www.google.com'
         },
        {
            bookname: 'Angular Book 2',
            title: 'Angular Book Description 2',
            link: 'http://www.google.com'
        },
        {
            bookname: 'Angular Book 3',
            title: 'Angular Book Description 3',
            link: 'http://www.google.com'
        }

    ];
*/

    addlink(bookname:HTMLInputElement,title:HTMLInputElement,link:HTMLInputElement){
        console.log(`Adding article Book Name : ${bookname.value} and Title: ${title.value} and Link : ${link.value} `);


     /*   console.log(this.contactList.push({
            bookname: bookname.value,
            title: title.value,
            link: link.value
        }));*/
        bookname.value="";
        title.value="";
        link.value="";
           }

    

}
class BookArticle{
    bookname: string;
    title: string;
    link: string;
    votes : number;
    addclass;

    constructor(bookname: string, title: string, link:string, votes?: number) {
        this.bookname = bookname;
        this.title = title;
        this.link=link;
        this.votes = votes || 0;
    }
    
    voteUp() : void {
        this.votes += 1 ;
         if(this.votes > 0){
            this.addclass ="green";
        }else{
            this.addclass ="red";
        }
    }

    voteDown() : void {
        this.votes -= 1 ;
         if(this.votes > 0){
            this.addclass ="green";
        }else{
            this.addclass ="red";
        }
    }
}

