import {bootstrap}    from 'angular2/platform/browser'
import {RedditApp} from './app.component'

bootstrap(RedditApp);